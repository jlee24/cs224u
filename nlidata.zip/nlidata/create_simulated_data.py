import json
from string import ascii_lowercase as letters
from collections import Counter
import numpy as np


def powerset(seq):
    """Returns all the subsets of this set. This is a generator."""
    if len(seq) <= 1:
        yield seq
        yield []
    else:
        for item in powerset(seq[1:]):
            yield [seq[0]]+item
            yield item

labels = ['disjoint', 'equal', 'neutral', 'subset', 'superset']


def get_y(rel):
    y = np.zeros(len(labels))
    y[labels.index(rel)] = 1.0
    return y


def generate_dataset(worlds=[1,2,3,4]):
    lang = {}
    for i, p in enumerate(list(powerset(worlds))):
        if p and p != worlds:
            lang[letters[i-1]] = set(p)

    print(len(lang))

    dataset = []
    for p, psem in lang.items():
        for q, qsem in lang.items():
            rel = None
            if psem == qsem:
                rel = 'equal'
            elif psem < qsem:
                rel = 'subset'
            elif psem > qsem:
                rel = 'superset'
            elif len(psem & qsem) == 0:
                rel = 'disjoint'
            elif psem & qsem:
                rel = 'neutral'
            dataset.append(([[p], [q]], rel))
    return dataset


dataset =  generate_dataset()

print(Counter([x[1] for x in dataset]))

print(len(dataset))

with open("nli_simulated_data.json", "wt") as f:
    json.dump(dataset, f)
